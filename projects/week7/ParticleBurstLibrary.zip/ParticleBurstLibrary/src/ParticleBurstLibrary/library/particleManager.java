/**
Modified Bryn Mawr College, Department of Computer Science's fireworks 
*/

package ParticleBurstLibrary.library;

import java.util.ArrayList;
import processing.core.*;

/**
 * This is a template class and can be used to start a new processing Library.
 * Make sure you rename this class as well as the name of the example package 'template' 
 * to your own Library naming convention.
 * 
 * (the tag example followed by the name of an example included in folder 'examples' will
 * automatically include the example in the javadoc.)
 *
 * @example Hello 
 */


public class particleManager{ 

	PApplet myParent;
	ArrayList<Burst> bursts; 
	
	public particleManager(PApplet theParent) {
		myParent = theParent;
		bursts = new ArrayList();
		
	}
	
	public void settings(){
    	myParent.size(800, 800);
    }

    public void setup(){
        myParent.fill(120,50,240);
    }

    public void draw(){
    	myParent.noStroke();
    	  // transparent black background
    	myParent.fill(0, 45);
    	myParent.rect(0, 0, myParent.width, myParent.height);
    	
    	for (int i = bursts.size() - 1; i >= 0; i--) {
		    Burst b = (Burst)bursts.get(i);
		    if (b.update()) bursts.remove(i);
		 }
    	
    }
    
    public void burst(float x, float y, int qty, int type){
	      Burst b = new Burst(this.myParent, x, y, qty, type);
	      this.bursts.add(b);
	}
}

