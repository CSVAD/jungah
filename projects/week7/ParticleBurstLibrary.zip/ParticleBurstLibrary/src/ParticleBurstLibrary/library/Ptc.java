package ParticleBurstLibrary.library;

import processing.core.PApplet;

public class Ptc {

}
