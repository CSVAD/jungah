package ParticleBurstLibrary.library;
import java.awt.Color;
//import processing.core.*;
import processing.core.PApplet;
//import controlP5.*;

import java.util.ArrayList;

public class Burst_space{
	  PApplet parent; 
	  float gravity; 
	  ArrayList<Particle> particles = new ArrayList<Particle>();
	  int particle_type; 

	  public Burst_space(PApplet p, float x, float y, int qty, int particle_type){
		parent = p; 
	    gravity = (float)0.7;
	    //gravity = 0.1;
	    Color c = new Color((int)parent.random(0, 255), (int)parent.random(0, 255), (int)parent.random(0, 255));
	    this.particle_type = particle_type; 
 
	    for (int i = 0; i < qty; i++){        
	      float vx = parent.random(-20, 20);
	      float vy = parent.random(-20, 20); 
	       
	      float sd = parent.random(10,60); 
	      
	      
	      
	      /*if (parent.random(1) < 0.8)
	        vy *= -1.5;*/
	      particles.add(new Particle(parent,x, y, vx, vy, c, particle_type));
	    }
	  }

	  public boolean update(){
	    for (int i = particles.size() - 1; i >= 0; i--){
	      Particle par = (Particle)particles.get(i);
	      //par.accelerate(gravity);
	      if (par.update()) particles.remove(i);
	    }    
	    return particles.size() == 0;
	  }
	  
}