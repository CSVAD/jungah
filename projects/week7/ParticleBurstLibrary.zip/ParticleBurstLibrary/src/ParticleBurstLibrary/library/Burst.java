package ParticleBurstLibrary.library;
import java.awt.Color;
//import processing.core.*;
import processing.core.PApplet;
//import controlP5.*;

import java.util.ArrayList;

public class Burst{
	  PApplet parent; 
	  float gravity;
	  ArrayList<Particle> particles = new ArrayList<Particle>();
	  int particle_type; 

	  public Burst(PApplet p, float x, float y, int qty, int particle_type){
		parent = p; 
	    gravity = (float)0.7;
	    //gravity = 0.1;
	    Color c = new Color((int)parent.random(100, 255), (int)parent.random(100, 255), (int)parent.random(100, 255));
	    //Color c = new Color(255,0,0); 
	    this.particle_type = particle_type; 
 
	    for (int i = 0; i < qty; i++){        
	      float vx = parent.random(-20, 20);
	      float vy = parent.random(0, 20);
	      if (parent.random(1) < 0.8)
	        vy *= -1.5;
	      particles.add(new Particle(parent,x, y, vx, vy, c, particle_type));
	    }
	  }

	  public boolean update(){
	    for (int i = particles.size() - 1; i >= 0; i--){
	      Particle par = (Particle)particles.get(i);
	      par.accelerate(gravity);
	      if (par.update()) particles.remove(i);
	    }    
	    return particles.size() == 0;
	  }
	  
}