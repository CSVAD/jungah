package ParticleBurstLibrary.library;
import java.awt.Color;

import processing.core.PApplet;

public class Particle {
	  PApplet parent;
	  float x, y;
	  float vx, vy;
	  Color c;
	  int type; 

	  public Particle(PApplet p, float x, float y, float vx, float vy, Color c, int type) {
		parent = p;
	    this.x = x;
	    this.y = y;
	    this.vx = vx;
	    this.vy = vy;
	    this.c = c;
	    this.type = type; 
	  }

	  public void accelerate(float a) {
	    vy += a;
	  }

	  public boolean update() {
		  
	    float px = x;
	    float py = y;
	    
	    x += vx;
	    y += vy;
	    float speed = parent.abs(x-px) + parent.abs(y-py);
	    parent.stroke(c.getRed(), c.getGreen(), c.getBlue()); 
	    if (type == parent.LINE) {  
	      parent.line(px, py, x, y);
	    } 
	    else if (type == parent.ELLIPSE) { 
	      parent.ellipse(x,y,speed,speed); 
	    }
	    else if (type == parent.RECT) {
	      parent.rect(x,y,speed,speed); 
	    } 
	    else if (type == parent.TRIANGLE) {
		      //parent.rect(x,y,speed,speed); 
		      parent.stroke(255,255,255);
		      int xDist = (int)(x-px);
		      int yDist = (int)(y-py);
		      float theta = parent.atan2(xDist,yDist);
		      
		      parent.pushMatrix();
		      parent.translate(x,y);
		      parent.rotate(parent.TWO_PI-theta);
		      //drawingManager.triangle(-10,0, 10, 0, 0,random(10,100));
		      //drawingManager.triangle(-10,0, 10, 0, 0,random(10,100));
		      int alpha = parent.round(parent.map(speed,0,40,10,100));
		      parent.triangle(-10,0, 10, 0, 0, alpha); 
		      //drawingManager.triangle(-10,0, 10, 0, 0, sqrt(300));
		      parent.popMatrix();
		}
	    else if (type == 3) {
	    	parent.ellipse(x,y,speed,speed); 
	    	parent.fill(255,255,255);
	        
	    	parent.ellipse(x,y,speed/2,speed/2);
	    	parent.noFill();
	    }
	    else if (type == 5) {
	    	parent.rect(x,y,speed,speed);
	    	parent.fill(255,255,255);
	    	parent.ellipse(x,y,speed/2,speed/2);
	    	parent.noFill();
	    }
	    else {
	    	parent.pushMatrix();
	    	parent.translate(x,y);
	        
	    	parent.line(-speed/2, -speed/2, speed/2,speed/2);
	    	parent.line(-speed/2, speed/2, speed/2, -speed/2);
	    	parent.popMatrix();
	    }
	    	
	    //ellipse(x,y,vx,vy);
	    //point(x,y); 
	    //ellipse(x,y,vx,vy);
	    //square(x,y,vy); 
	    
	    return y > parent.height || x < 0 || x > parent.width;
	  }
}